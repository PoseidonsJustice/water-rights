This directory contains 3 copies of the water_rights database. They are saved in different formats to allow for greater flexibility in restoring the database.

water_rights_compressed.backup = postgresql standard compressed backup format
water_rights_plain.backup = sql format
water_rights_tar.backup = a compressed .tar format